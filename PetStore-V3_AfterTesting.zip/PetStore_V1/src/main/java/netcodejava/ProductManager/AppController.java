package netcodejava.ProductManager;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AppController {
	@Autowired
	private ProductService service;

	@RequestMapping("/")
	public String home(Model model) {

		return "Login";
	}

	@RequestMapping(value = "/home")

	public String ShowLogin(@RequestParam(value = "username") String username,
			@RequestParam(value = "password") String password, Model model) {
		model.addAttribute("username", username);
		model.addAttribute("password", password);
		boolean isvalidUser = service.validateUser(username, password);

		if (!isvalidUser) {
			System.out.println("Invalid username and password");
			model.addAttribute("Invalid ", "Invalid Credentials");
			return "redirect:/";
		}
		return "index";
	}

	@RequestMapping("/catalog")
	public String viewListOFProducts(Model model) {
		try {
			List<Product> listProducts = service.listAll();
			model.addAttribute("listProducts", listProducts);
		} catch (RuntimeException e) {
			System.out.println("No product found");
		} finally {
			System.out.println("The 'try catch of ViewHome Method is finished.");
		}
		return "index";
	}

	@RequestMapping("/new")
	public String ShwoNewProduct(Model model) {
		try {
			Product product = new Product();
			model.addAttribute("product", product);
		} catch (Exception e) {
			System.out.println("Something wrong with Link to creat product Method");
		} finally {
			System.out.println("The 'try catch'  ShwoNewProduct  Method is finished.");
		}
		return "new_product";
	}

	@RequestMapping(value = "/cart/{id}")
	public String ShowCart(Model model, @PathVariable("id") Long id) {
		try {

			model.addAttribute("product", service.get(id));
		} catch (IllegalArgumentException e) {
			System.out.println("Something wrong with ShowViewProduct Method");
		} finally {
			System.out.println("The 'try catch' ShwoNewProduct  is finished.");
		}
		return "Cart";
	}

	@RequestMapping(value = "/buy/{id}")
	public String buyNewProduct(Model model, @PathVariable("id") Long id) {
		try {

			model.addAttribute("product", service.get(id));
		} catch (Exception e) {
			System.out.println("Something wrong with buyNewProduct Method");
		} finally {
			System.out.println("The 'try catch' is finished.");
		}
		return "buy";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("product") Product product) {
		try {
			service.save(product);
		} catch (NullPointerException e) {
			System.out.println("Something wrong saveProduct with Save Method");
		}
		return "redirect:/";

	}
}
