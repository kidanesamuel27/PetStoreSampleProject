package netcodejava.ProductManager;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class AppControllerTest {
	@InjectMocks
	AppController appController;

	@Mock
	ProductRepository repository;

//	private Object mockMvc;
	private MockMvc mockMvc;
	private Model model;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(appController).build();
	}

	@Test
	public void testSaveProduct() {
		Product product = new Product();
		Product pro = new Product((long) 1, "Dog", "Yes", 1001);
		when(repository.save(pro)).thenReturn(pro);
		assertEquals(pro, repository.save(pro));
	}

	@Test
	public void testShowLogin() throws Exception {
		this.mockMvc.perform(get("/")).andExpect(status().isOk());
	}

	@Test
	public void viewListOFProductsTest() throws Exception {
		this.mockMvc.perform(get("/catalog")).andExpect(status().isOk());

	}

	@Test
	public void ShowCartTest() throws Exception {
		this.mockMvc.perform(get("/")).andExpect(status().isOk());
	}

}