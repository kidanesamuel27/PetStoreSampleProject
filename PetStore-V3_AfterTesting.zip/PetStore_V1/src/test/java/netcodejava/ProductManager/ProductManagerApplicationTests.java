package netcodejava.ProductManager;
import org.junit.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ui.Model;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class ProductManagerApplicationTests {
//	@Mock
//	ProductService service;
//	@InjectMocks	
//	ProductRepository repository;
//	ProductService Service;
//

	@Test
	public void contextLoads() {
	}
}

//@Test
//	public void viewHomePageTest() {
//		Product Temp= new Product((long) 1,"Dog","Yes",(float) 100.01);
//		when(repo.findAll()).thenReturn(Stream.of(Temp).collect(Collectors.toList()));
//		assertEquals(1,service.listAll());}
//			}

//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class ProductManagerApplicationTests {
//
//
//
//
//@Autowired
//@MockBean
//	private ProductService productservice;
//
//@MockBean
//private ProductRepository repository;
//@Test
//public void contextLoads() {
//}
//
//@Test
//public void viewHomePageTest() {
//	Product pro= new Product((long) 1,"Dog","Yes",1001);
//	when(repository.viewHomePage()).thenReturn(Stream.of(pro).collect(Collectors.toList()));
//	assertEquals(1,((List<Product>) repository.viewHomePage()).size());}
//
//
//
//
////@Test
////public void ShwoNewProductTest()
////{
////long id=1;
////when(repository.ShwoNewProduct()).thenReturn(productservice.get(id));
////assertEquals(1,repository.ShwoNewProduct());
////}