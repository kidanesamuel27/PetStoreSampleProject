package netcodejava.ProductManager;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest

public class ProductServiceTest {

	@InjectMocks
	ProductService productService;

	@Mock
	ProductRepository repository;

//		private Object mockMvc;
	private MockMvc mockMvc;
	private Model model;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(productService).build();
	}

	@Test
	public void testViewHomePageService() {
		Product pro = new Product((long) 1, "Dog", "Yes", 1001);
		when(repository.findAll()).thenReturn(Stream.of(pro).collect(Collectors.toList()));
		assertEquals(1, repository.findAll().size());

	}

	@Test
	public void saveTest() {
		Product prod = new Product((long) 3, "Dog", "Yes", 1001);

		when(repository.save(prod)).thenReturn(prod);
		assertEquals(prod, repository.save(prod));
	}

}
